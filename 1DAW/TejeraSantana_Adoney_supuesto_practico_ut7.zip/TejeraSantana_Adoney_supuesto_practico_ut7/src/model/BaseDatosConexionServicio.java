
//@@@@@@@@@@@@@@@@ PROYECTO Brandom-Adoney


package model;

/**
 *
 * González Olivares Brandon - Tejera Santana Adoney
 */
public class BaseDatosConexionServicio {
    
}
