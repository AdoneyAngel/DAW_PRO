
//@@@@@@@@@@@@@@@@ PROYECTO Brandom-Adoney


package model.sistema_pedidos;

/**
 *
 * González Olivares Brandon - Tejera Santana Adoney
 */
public class FinalizarPedidoModel {
    
}
