
//@@@@@@@@@@@@@@@@ PROYECTO Brandom-Adoney


package model.administracion.gestion;

/**
 *
 * González Olivares Brandon - Tejera Santana Adoney
 */
public class GestionMesasModel {
    
}
