/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.interfaz;

import java.util.List;
import model.Carta;

/**
 *
 * @author AdoneyDAW
 */
public interface iCartas_tiposCarta {
    List<Carta> getCartasDeTipo (String nombreTipo);
}
