
//@@@@@@@@@@@@@@@@ PROYECTO Brandom-Adoney


package model.administracion.gestion;

/**
 *
 * @author AdoneyDAW
 */
public class GestionMesasModel {
    
}
