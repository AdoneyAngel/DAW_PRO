
//@@@@@@@@@@@@@@@@ PROYECTO Brandom-Adoney


package model.administracion.historial_pedidos;

/**
 *
 * @author AdoneyDAW
 */
public class HistorialPedidosModel {
    
}
